package org.jedrzej.kapisz.Messager_FINAL.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.NotFoundException;

import org.jedrzej.kapisz.Messager_FINAL.dataBase.DataBaseSimulator;
import org.jedrzej.kapisz.Messager_FINAL.model.Comment;
import org.jedrzej.kapisz.Messager_FINAL.model.Message;

public class CommentService {

	private Map<Long, Message> messages = DataBaseSimulator.getMessages();
	public List <Comment> getAllComments (long messageId){
		Message message = messages.get(messageId);
		if(message == null) {
			throw new NotFoundException();	//WebApplicationException-ScionPotomek
		}
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		return new ArrayList<Comment>(comments.values());
	}
	
	public Comment getComment(long messageId, long commentId) {
		Map <Long, Comment> comments = messages.get(messageId).getComments();
		return comments.get(commentId);
	}
	
	public Comment addComment(Long messageId, Comment comment) {
		Map <Long, Comment> comments = messages.get(messageId).getComments();
		comment.setId(comments.size()+1);
		comments.put(comment.getId(), comment);
		messages.get(messageId).setComments(comments);	//poprawione1
		return comment;
	}
	
	public Comment updateComment(Long messageId, Comment comment) {
		Map <Long, Comment> comments = messages.get(messageId).getComments();
		if(comment.getId()<=0) {
			return null;
		}
		comments.put(comment.getId(), comment);
		messages.get(messageId).setComments(comments);	//poprawione1
		return comment;
	}
	
	public Comment removeComment(long messageId, long commentId) {
		Map<Long, Comment> comments = messages.get(messageId).getComments();
		return comments.remove(commentId);
	}
	
}

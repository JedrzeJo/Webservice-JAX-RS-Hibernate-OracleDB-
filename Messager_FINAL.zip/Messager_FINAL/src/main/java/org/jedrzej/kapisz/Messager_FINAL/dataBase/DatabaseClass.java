package org.jedrzej.kapisz.Messager_FINAL.dataBase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.jedrzej.kapisz.Messager_FINAL.model.Profile;

public class DatabaseClass {
	
	static Connection con = null;
	static Statement stmt = null;
	static Scanner sc;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe","system","jeremi16");
			stmt = con.createStatement();
			//You are connected with the Database MessagerDB
			String query = "USE MessagerDB";
			stmt.execute(query);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList <Profile> readAllProfiles() {
		ArrayList <Profile> ProfilesList = new ArrayList <Profile>();
		try {
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Profiles");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Profile localProfile = new Profile();
				localProfile.setId(rs.getInt("id"));
				localProfile.setProfileName(rs.getString("profileName"));
				localProfile.setFirstName(rs.getString("firstName"));
				localProfile.setLastName(rs.getString("lastName"));
				localProfile.setCreated(rs.getDate("dateCreated"));		
				ProfilesList.add(localProfile);
			}
			con.close();
			return ProfilesList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Profile readProfile(String profileName) {
		Profile localProfile = new Profile ();
		try {
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Profiles WHERE profileName="+profileName);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				localProfile.setId(rs.getInt("id"));
				localProfile.setProfileName(rs.getString("profileName"));
				localProfile.setFirstName(rs.getString("firstName"));
				localProfile.setLastName(rs.getString("lastName"));
				localProfile.setCreated(rs.getDate("dateCreated"));		
			}
			con.close();
			return localProfile;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Profile insertProfile(Profile profile) {
		Profile localProfile = new Profile ();
		try {
			stmt = con.createStatement();
			String sql = "INSERT INTO Profiles (id, profileName, firstName, lastNAme, dateCreated) VALUES('"+profile.getId()+"','"+profile.getProfileName()+"','"+profile.getFirstName()+"','"+profile.getLastName()+"','"+profile.getCreated()+"')";
			stmt.execute(sql);
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Profiles WHERE profileName="+profile.getProfileName());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				localProfile.setId(rs.getInt("id"));
				localProfile.setProfileName(rs.getString("profileName"));
				localProfile.setFirstName(rs.getString("firstName"));
				localProfile.setLastName(rs.getString("lastName"));
				localProfile.setCreated(rs.getDate("dateCreated"));		
			}
			con.close();
			return localProfile;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Profile update(Profile profile) {
		Profile localProfile = new Profile ();
		try {
			PreparedStatement ps = con.prepareStatement("UPDATE Profiles SET profileName = '"+profile.getProfileName()+"'WHERE id ='"+profile.getId()+"'");
			int rs = ps.executeUpdate();
			if (rs > 0) {
				//record updated
				PreparedStatement ps2 = con.prepareStatement("SELECT * FROM Profiles WHERE profileName="+profile.getProfileName());
				ResultSet rs2 = ps2.executeQuery();
				while (rs2.next()) {
					localProfile.setId(rs2.getInt("id"));
					localProfile.setProfileName(rs2.getString("profileName"));
					localProfile.setFirstName(rs2.getString("firstName"));
					localProfile.setLastName(rs2.getString("lastName"));
					localProfile.setCreated(rs2.getDate("dateCreated"));		
				}
				con.close();
				return localProfile;
			}
			else { return null;}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void delete(String profileName) {
		try {
			stmt.execute("DELETE FROM Profiles WHERE profileName = "+profileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
package org.jedrzej.kapisz.Messager_FINAL.dataBase;

import java.util.HashMap;
import java.util.Map;

import org.jedrzej.kapisz.Messager_FINAL.model.Message;

public class DataBaseSimulator {
	
	private static Map <Long, Message> messages= new HashMap<>();
	
	public static Map<Long, Message> getMessages(){
		return messages;
	}
}

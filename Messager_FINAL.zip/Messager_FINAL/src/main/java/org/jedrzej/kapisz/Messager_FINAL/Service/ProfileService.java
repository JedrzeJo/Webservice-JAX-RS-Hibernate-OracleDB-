package org.jedrzej.kapisz.Messager_FINAL.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jedrzej.kapisz.Messager_FINAL.dataBase.DatabaseClass;
import org.jedrzej.kapisz.Messager_FINAL.model.Profile;

public class ProfileService {

	//private Map <String, Profile> profiles = DataBaseSimulator.getProfiles();
	private static DatabaseClass DBprofiles = new DatabaseClass();
	
	public ProfileService() {
	}
	 
	public List <Profile> getAllProfiles(){
		/*DBprofiles.connect();
		return DBprofiles.readAllProfiles();*/
		Profile profile1 = new Profile (1L, "jeremi", "jedrzej", "kapisz");
		Profile profile2 = new Profile (2L, "klaudio", "test", "testowy");
		List <Profile> list = new ArrayList();
		list.add(profile1);
		list.add(profile2);
		return list;
		
	}
	 
	public Profile getProfile(String profileName) {
		DBprofiles.connect();
		return DBprofiles.readProfile(profileName);
	}

	public Profile addProfile(Profile profile) {
		DBprofiles.connect();
		profile.setId(DBprofiles.readAllProfiles().size()+1);
		return DBprofiles.insertProfile(profile);
	}
	
	public Profile updateProfile(String profileName, Profile profile) {
		if(profile.getProfileName().isEmpty()) {
			return null;
		}
		DBprofiles.connect();
		profile.setProfileName(profileName);
		return DBprofiles.update(profile);
	}

	public void removeProfile(String profileName) {
		DBprofiles.connect();
		DBprofiles.delete(profileName);
	}
}
